using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;

public class ServerManager : MonoBehaviour
{
    [SerializeField] private ItembuttonManager itemBtnManager;
    [SerializeField] private GameObject buttonContainer;
    [SerializeField] private GameObject buttonContainerSearch;
    [SerializeField] private GameObject buttonContainerRecommendation;
    public TMP_InputField SearchText;
    private UIManager uiManager;

    [Serializable]
    public struct Items
    {
        [Serializable]
        public struct Item
        {
            public string Name;
            public string Description;
            public PlaneType Planetype;
            public category category;
            public styles styles;
            public string URLBundleModel;
            public string URLImageModel;
            public string URLArticulo;
        }

        public Item[] items;
    }

    public Items newItemsCollection = new Items();

    void Start()
    {
        uiManager = FindObjectOfType<UIManager>();
        StartCoroutine(GetJsonData());
        GameManager.instance.OnItemsMenu += createButtons;
        uiManager.ItemsMenuMuebles += createButtonsMuebles;
        uiManager.ItemsMenuDeco += createButtonsDeco;
        uiManager.ItemsMenuElectro += createButtonsElectro;

        SearchText.onValueChanged.AddListener(delegate { createButtonsSearch(); });
    }

    private void createButtons()
    {
        foreach (var item in newItemsCollection.items)
        {
            ItembuttonManager itembutton;
            itembutton = Instantiate(itemBtnManager, buttonContainer.transform);
            itembutton.name = item.Name;
            itembutton.ItemName = item.Name;
            itembutton.ItemDescription = item.Description;
            itembutton.PlaneType = item.Planetype;
            itembutton.Category = item.category;
            itembutton.Estilo = item.styles;
            itembutton.URLBundleModel = item.URLBundleModel;
            itembutton.URLArticulo = item.URLArticulo;
            StartCoroutine(GetBundleImg(item.URLImageModel, itembutton));
        }
    }

    private void createButtonsN(int category)
    {
        foreach (var item in newItemsCollection.items)
        {
            if ((int)item.category == category)
            {
                ItembuttonManager itembutton;
                itembutton = Instantiate(itemBtnManager, buttonContainer.transform);
                itembutton.name = item.Name;
                itembutton.ItemName = item.Name;
                itembutton.ItemDescription = item.Description;
                itembutton.PlaneType = item.Planetype;
                itembutton.Category = item.category;
                itembutton.Estilo = item.styles;
                itembutton.URLBundleModel = item.URLBundleModel;
                itembutton.URLArticulo = item.URLArticulo;
                StartCoroutine(GetBundleImg(item.URLImageModel, itembutton));
            }
        }
    }

    private void createButtonsMuebles()
    {
        createButtonsN(1);
    }

    private void createButtonsDeco()
    {
        createButtonsN(2);
    }

    private void createButtonsElectro()
    {
        createButtonsN(0);
    }

    private void createButtonsSearch()
    {
        delArticuloSearch();
        string searchTextLower = SearchText.text.ToLower();
        foreach (var item in newItemsCollection.items)
        {
            string itemNameLower = item.Name.ToLower();
            if (itemNameLower.Contains(searchTextLower))
            {
                ItembuttonManager itembutton;
                itembutton = Instantiate(itemBtnManager, buttonContainerSearch.transform);
                itembutton.name = item.Name;
                itembutton.ItemName = item.Name;
                itembutton.ItemDescription = item.Description;
                itembutton.PlaneType = item.Planetype;
                itembutton.Category = item.category;
                itembutton.Estilo = item.styles;
                itembutton.URLBundleModel = item.URLBundleModel;
                itembutton.URLArticulo = item.URLArticulo;
                StartCoroutine(GetBundleImg(item.URLImageModel, itembutton));
            }
        }
    }

    public void delArticulo()
    {
        if (buttonContainer != null)
        {
            foreach (Transform articulo in buttonContainer.transform)
            {
                Destroy(articulo.gameObject);
            }
        }
    }

    public void delArticuloSearch()
    {
        if (buttonContainerSearch != null)
        {
            foreach (Transform articulo in buttonContainerSearch.transform)
            {
                Destroy(articulo.gameObject);
            }
        }
    }

    IEnumerator GetJsonData()
    {
        string serverURL = "http://regional-sociology.gl.at.ply.gg:24198";
        UnityWebRequest request = UnityWebRequest.Get(serverURL + "/jsondata");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            newItemsCollection = JsonUtility.FromJson<Items>("{\"items\":" + request.downloadHandler.text + "}");
        }
        else
        {
            Debug.LogError("Failed to fetch JSON data: " + request.error);
        }
    }

    IEnumerator GetBundleImg(string urlImage, ItembuttonManager button)
    {
        UnityWebRequest request = UnityWebRequest.Get(urlImage);
        request.downloadHandler = new DownloadHandlerTexture();
        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            button.URLImgModel.texture = ((DownloadHandlerTexture)request.downloadHandler).texture;
        }
        else
        {
            Debug.LogError("Failed to download image: " + request.error);
        }
    }
}