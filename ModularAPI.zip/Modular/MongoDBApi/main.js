const { MongoClient } = require("mongodb");
const Express = require("express");
const BodyParser = require('body-parser');

const server = Express();
const client = new MongoClient(process.env.ATLAS_URI);

//playit
//conexión a mongodb a través de VSC
//$env:ATLAS_URI = "mongodb+srv://FridaLaDogga:1105@decoar.rhxqfhb.mongodb.net/?retryWrites=true&w=majority&appName=DecoAR" //Inicializacion de variable de entorno temporal
//npm start


server.use(BodyParser.json());

var collection;

server.post("/Users", async (request, response, next) => {
    try {
        let correo = request.body.correo;
        let password = request.body.password;

        console.log(request.body); // Verificar que se estén recibiendo los datos en el servidor

        let result = await collection.insertOne({ correo, password, cat1, cat2, cat3 });

        response.status(201).send({ message: "Usuario creado correctamente" });
        console.log(`Correo: ${correo}, Password: ${password}`);
    } catch (e) {
        response.status(500).send({ message: e.message });
    }
});


server.get("/Users", async (request, response, next) => {
    try {
        let correo = request.query.correo; // Obtener el correo proporcionado por el usuario
        let password = request.query.password; // Obtener la contraseña proporcionada por el usuario

        // Comprobar si se proporcionaron el correo y la contraseña
        if (!correo || !password) {
            response.status(400).send({ message: "Favor de ingresar a través de la aplicación." });
            return;
        }

        // Buscar un usuario que coincida exactamente con el correo y la contraseña proporcionados
        let result = await collection.find({ correo: correo, password: password }).toArray();

        if (result.length === 0) {
            response.status(404).send({ message: "Usuario no encontrado con el correo y contraseña proporcionados." });
        } else {
            response.send(result);
        }
    } catch (e) {
        response.status(500).send({ message: e.message });
    }
});

//Busqueda: http://regional-sociology.gl.at.ply.gg:24198/search?term=<termino>
server.get("/search", async (request, response) => {
    try {
        let result = await client.db("DecoAR").collection("Muebles").aggregate([
            {
                "$search": {
                    "index": "MueblesPlotIndex",
                    "text": {
                        "query": request.query.term,
                        "path": "plot",
                        "fuzzy": {
                            "maxEdits": 2
                        }
                    }
                }
            },
            {
                "$project": {
                    "_id": 0, // Excluir campos del resultado
                    "plot": 0
                }
            }
        ]).toArray();
        response.send(result);
    } catch (e) {
        response.status(500).send({ message: e.message });
    }
});

//Busqueda: http://regional-sociology.gl.at.ply.gg:24198/jsondata
server.get("/jsondata", async (request, response) => {
    try {
        let result = await client.db("DecoAR").collection("Muebles").find({}, { projection: { _id: 0, plot: 0 } }).toArray();
        response.send(result);
    } catch (e) {
        response.status(500).send({ message: e.message });
    }
});

server.listen("3000", async() => {
    try {
        await client.connect();
        collection = client.db("DecoAR").collection("Users");
        console.log("Connected to MongoDB");
        console.log("Listening at :3000...");
    } catch (e) {
        console.error("Error connecting to MongoDB:", e);
        process.exit(1); // Cierra el proceso en caso de no poder conectarse
    }
});